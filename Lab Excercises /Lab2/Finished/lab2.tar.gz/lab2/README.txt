Name: Patricia Zapansa
Lab: CMPT201 - 

It is important to catch regressions early on and as quickly as 
possible because you can't just assume that if something once 
worked, its going to work again after you make a change. Small and 
seemingly insignificant changes to a programs' code can potentially 
break it. It's better to know exactly what you changed that 
broke the progream since the last successful test, than to make 
SEVERAL changes, then test the program then realize it's not 
working. You won't know at what point, where things went wrong. 
You'd have to backtrack a lot more than if you had done the former.   
