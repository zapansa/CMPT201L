/*-------------------------------------------------------
# Student's Name: Patricia Zapansa
# Lab Excercise #5, Part (#1)
# Lab Section: 201-X02L
# Lab Instructor’s Name: Calin Anton
# CMPUT 201
# Instructor's Name: Calin Anton
*------------------------------------------------------*/
#include<string.h>
#include<stdio.h>
#define MAXSTR 80

/* This function is called in main and reads the input that the
   user enters and counts the amount of characters the input is.
   Precondition: A char array and an integer need to be passed in
   Postcondition: The char array is read and is null terminated
*/
void safeReadString(char *str,int size);
